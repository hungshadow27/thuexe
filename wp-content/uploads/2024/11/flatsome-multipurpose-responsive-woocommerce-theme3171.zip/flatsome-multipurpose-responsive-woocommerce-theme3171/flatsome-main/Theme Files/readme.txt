Contains the parent and child theme .zip installation files

# Please visit the following link to learn more about adding a new theme:

https://wordpress.org/support/article/using-themes/#adding-new-themes
